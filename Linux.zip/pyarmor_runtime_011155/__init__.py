# Pyarmor 9.2.0 (pro), 011155, 2025-12-23T22:37:25.618648
from .pyarmor_runtime import __pyarmor__
